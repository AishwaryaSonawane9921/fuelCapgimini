package com.example.demoCartShopping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCartShoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
